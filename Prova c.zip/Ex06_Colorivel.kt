interface Colorivel {
    fun cor(): String  // Declaração do método abstrato
}
