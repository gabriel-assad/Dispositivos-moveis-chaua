fun main() {
    val carro = Carro("Toyota", "Corolla", "Prata")  // Criação de um objeto Carro
    val casa = Casa("Rua Principal, 123", "Branca")  // Criação de um objeto Casa

    println("A cor do carro é: ${carro.cor()}")  // Exibe a cor do carro
    println("A cor da casa é: ${casa.cor()}")  // Exibe a cor da casa
}
